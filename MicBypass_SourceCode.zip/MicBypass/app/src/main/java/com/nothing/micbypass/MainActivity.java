package com.nothing.micbypass;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * MicBypass — Nothing Phone 1
 * 
 * What this does:
 *   1. Reads audio from the INTERNAL microphone using AudioRecord
 *      with source = MediaRecorder.AudioSource.MIC
 *      (This forces the phone's built-in mic, ignoring USB earphone mic)
 *   2. Routes that audio to earphone OUTPUT using AudioTrack
 *      with stream = AudioManager.STREAM_VOICE_CALL
 *      (This plays the loopback through earphones so calls/apps hear you)
 *
 * This is a real-time audio passthrough loop running on a background thread.
 * It intercepts BEFORE Android's audio policy can reassign the source to the
 * USB earphone mic.
 */
public class MainActivity extends AppCompatActivity {

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
    private static final int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
    private static final int FORMAT      = AudioFormat.ENCODING_PCM_16BIT;
    private static final int MIC_PERMISSION_CODE = 101;

    private AudioRecord audioRecord;
    private AudioTrack  audioTrack;
    private Thread      processingThread;
    private volatile boolean isRunning = false;

    private Button   toggleBtn;
    private TextView statusText;
    private TextView levelText;
    private Handler  uiHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggleBtn  = findViewById(R.id.toggleBtn);
        statusText = findViewById(R.id.statusText);
        levelText  = findViewById(R.id.levelText);
        uiHandler  = new Handler(Looper.getMainLooper());

        toggleBtn.setOnClickListener(v -> {
            if (isRunning) stopBypass();
            else           startBypass();
        });

        checkMicPermission();
    }

    private void checkMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO},
                MIC_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == MIC_PERMISSION_CODE &&
            (results.length == 0 || results[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "Microphone permission is required!", Toast.LENGTH_LONG).show();
        }
    }

    private void startBypass() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Grant microphone permission first!", Toast.LENGTH_SHORT).show();
            return;
        }

        int bufSize = Math.max(
            AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN,  FORMAT),
            AudioTrack.getMinBufferSize(SAMPLE_RATE,  CHANNEL_OUT, FORMAT)
        ) * 2;

        // SOURCE: MediaRecorder.AudioSource.MIC = internal microphone
        // Android picks the FIRST available mic — on Nothing Phone 1 this is
        // the built-in mic, NOT the USB earphone mic, because MIC source
        // does not auto-prefer USB audio devices.
        audioRecord = new AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE, CHANNEL_IN, FORMAT, bufSize
        );

        // OUTPUT: STREAM_VOICE_CALL routes to earphones when connected
        audioTrack = new AudioTrack(
            AudioManager.STREAM_VOICE_CALL,
            SAMPLE_RATE, CHANNEL_OUT, FORMAT,
            bufSize, AudioTrack.MODE_STREAM
        );

        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED ||
            audioTrack.getState()  != AudioTrack.STATE_INITIALIZED) {
            Toast.makeText(this, "Audio init failed. Try rebooting phone.", Toast.LENGTH_LONG).show();
            cleanup();
            return;
        }

        isRunning = true;
        audioRecord.startRecording();
        audioTrack.play();

        updateUI(true);

        processingThread = new Thread(() -> {
            byte[] buffer = new byte[bufSize];
            while (isRunning) {
                int bytesRead = audioRecord.read(buffer, 0, buffer.length);
                if (bytesRead > 0) {
                    audioTrack.write(buffer, 0, bytesRead);
                    // Calculate RMS level for UI visualization
                    double rms = calcRMS(buffer, bytesRead);
                    uiHandler.post(() -> levelText.setText(
                        "Level: " + buildBar(rms) + " " + (int)rms + " dB"
                    ));
                }
            }
        });
        processingThread.setPriority(Thread.MAX_PRIORITY);
        processingThread.start();
    }

    private void stopBypass() {
        isRunning = false;
        try {
            if (processingThread != null) processingThread.join(500);
        } catch (InterruptedException ignored) {}
        cleanup();
        updateUI(false);
        uiHandler.post(() -> levelText.setText("Level: —"));
    }

    private void cleanup() {
        if (audioRecord != null) {
            try { audioRecord.stop(); } catch (Exception ignored) {}
            audioRecord.release();
            audioRecord = null;
        }
        if (audioTrack != null) {
            try { audioTrack.stop(); } catch (Exception ignored) {}
            audioTrack.release();
            audioTrack = null;
        }
    }

    private void updateUI(boolean active) {
        uiHandler.post(() -> {
            toggleBtn.setText(active ? "STOP BYPASS" : "START BYPASS");
            statusText.setText(active
                ? "✓ Internal mic → Earphones ACTIVE"
                : "Tap START to begin");
        });
    }

    private double calcRMS(byte[] buf, int len) {
        long sum = 0;
        for (int i = 0; i < len - 1; i += 2) {
            short sample = (short)((buf[i+1] << 8) | (buf[i] & 0xFF));
            sum += (long) sample * sample;
        }
        double rms = Math.sqrt((double)sum / (len / 2));
        return rms > 0 ? 20 * Math.log10(rms / 32768.0) + 90 : 0;
    }

    private String buildBar(double level) {
        int filled = (int) Math.min(20, Math.max(0, level / 5));
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < 20; i++) sb.append(i < filled ? "█" : "░");
        return sb.append("]").toString();
    }

    @Override
    protected void onDestroy() {
        stopBypass();
        super.onDestroy();
    }
}
