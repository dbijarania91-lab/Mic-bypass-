# MicBypass — Nothing Phone 1
## Use Internal Mic + Earphone Audio Output simultaneously

---

## What this app does

Android normally hands over ALL audio (input + output) to USB-C earphones when they are plugged in.

This app bypasses that by:
1. Capturing audio from the **internal microphone** using `MediaRecorder.AudioSource.MIC`
   — this source does NOT auto-route to USB earphone mic
2. Sending it back out through **earphone audio output** via `AudioManager.STREAM_VOICE_CALL`

Result: You hear sound in your earphones, but your voice is picked up by the phone's built-in mic.

---

## How to build and install (No PC needed — use GitHub Actions or Android Studio)

### Option A — Android Studio (Recommended, needs a PC once)

1. Install Android Studio on your PC/laptop
2. Download this entire MicBypass folder
3. Open it in Android Studio → File → Open
4. Click ▶ Run (with your phone connected via USB, USB Debugging ON)
5. App installs directly on your phone

### Option B — Online build (No PC at all)

1. Upload this project to GitHub (free account)
2. GitHub Actions will auto-build the APK (use Android CI workflow)
3. Download the APK from Actions artifacts
4. Install on phone: Settings → Install unknown apps → allow your browser

---

## Enable USB Debugging (required for Option A)

1. Settings → About Phone
2. Tap Build Number **7 times**
3. Settings → System → Developer Options → USB Debugging → ON
4. Connect phone to PC, allow the connection prompt

---

## App permissions required

- `RECORD_AUDIO` — to access internal microphone
- `MODIFY_AUDIO_SETTINGS` — to control audio routing

Both are standard Android permissions, no root needed.

---

## How to use

1. Plug in your USB-C earphones
2. Open MicBypass app
3. Tap **START BYPASS**
4. Grant microphone permission if asked
5. Now make a call / use WhatsApp / record — voice comes from internal mic, sound goes to earphones
6. Tap **STOP BYPASS** when done

---

## Project structure

```
MicBypass/
├── app/
│   ├── src/main/
│   │   ├── java/com/nothing/micbypass/
│   │   │   └── MainActivity.java        ← Main app logic
│   │   ├── res/layout/
│   │   │   └── activity_main.xml        ← UI layout
│   │   └── AndroidManifest.xml          ← App config + permissions
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

---

## Technical explanation

```
USB-C Earphones plugged in
         │
         ├── AUDIO OUTPUT ──► AudioTrack (STREAM_VOICE_CALL) ──► Earphones ✓
         │
         └── MIC INPUT ──────► BLOCKED by app
                                     │
Nothing Phone 1 Internal Mic ──────► AudioRecord (MIC source) ──► Apps/Calls ✓
```

The key insight: `MediaRecorder.AudioSource.MIC` in Android refers to the primary microphone hardware, which on Nothing Phone 1 resolves to the internal mics — not the USB accessory mic. The USB earphone mic would only be selected automatically if using `AudioSource.DEFAULT` after plug-in.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| App says "Audio init failed" | Reboot phone, try again |
| Voice sounds echoed | Lower earphone volume slightly |
| Works for calls but not WhatsApp | WhatsApp has its own audio routing — run bypass first, then open WhatsApp |
| "Permission denied" | Go to Settings → Apps → MicBypass → Permissions → Microphone → Allow |

---

## Limitations

- Does NOT work for calls if the phone dialer overrides audio routing at HAL level
- For calls, also enable "Disable USB Audio Routing" in Developer Options alongside this app
- This app is a passthrough — it adds ~20ms latency (imperceptible for calls)
